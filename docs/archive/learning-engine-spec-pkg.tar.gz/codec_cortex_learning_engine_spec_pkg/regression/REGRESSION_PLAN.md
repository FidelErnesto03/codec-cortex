# Regression plan — CODEC-CORTEX Learning Engine

Run before and after implementation:

```bash
pytest
```

Run after implementation:

```bash
cortex learn init --workspace .
cortex learn doctor
cortex learn policy validate
cortex learn index rebuild
cortex learn index status
cortex learn scan --json
cortex learn candidates --limit 10 --json
```

Certification blockers:

- Existing tests fail.
- Learning tests fail.
- `learn scan` mutates `brain.cortex`.
- The learning engine calls a network service or LLM.
- Policy evaluator uses `eval` or `exec`.
- Critical sigils can be modified by a common policy.
- Index cannot be rebuilt from brain + policies.
