# Acceptance tests required for CODEC-CORTEX Learning Engine

The development agent must implement automated tests for:

1. Workspace initialization and idempotency.
2. Manifest parsing and validation.
3. Policy parsing and safe condition evaluation.
4. Learning index rebuild, invalidation and determinism.
5. Candidate detection using Fibonacci/golden-ratio thresholds.
6. Dry-run elevation without brain mutation.
7. Policy-authorized elevation with protected sigil blocking.
8. Regression: all existing project tests must pass.
9. Certification: no LLM calls, no network dependency, no eval/exec policy execution.
