#!/usr/bin/env python3
"""v0.3.2 — Add VIEW directives to each .cortex file in the benchmark corpus.

For each of the 10 corpus artefacts at
``benchmarks/v2.0.0/corpus/source/*.cortex`` we append a new ``$N: VIEWS``
section containing VIEW directives that cover every eligible entry. After
migration, ``cortex verify-view`` should report 100% coverage and
``cortex canonicalize`` should detect the artefact as VIEW-aware and
apply full canonicalization.

The migration is idempotent: if a ``$N: VIEWS`` section is already
present, it is replaced rather than duplicated.

Run::

    python /home/z/my-project/scripts/migrate_corpus_views.py
"""

from __future__ import annotations

import os
import re
import sys
from pathlib import Path

CORPUS_DIR = Path(
    "/home/z/my-project/work/codec-cortex/benchmarks/v2.0.0/corpus/source"
)

# Sigils we know how to render.  Each entry: (sigil, view_kind, reverse,
# fields_or_None, title).  The migration script picks the right ones per
# file based on which sigils are actually present.
SIGIL_VIEW_TEMPLATES = [
    # (sigil,   kind,        reverse,                 fields,                 title)
    ("IDN",   "kv_table",  "row_to_attrs",          "name,role,team,vendor,area,version,type,status", "Identity"),
    ("DOM",   "kv_table",  "row_to_attrs",          "area,project,building,zone,cluster,service", "Domain"),
    ("CNST",  "table",     "rows_to_entries",       "rule,severity,survive", "Constraints"),
    ("FCS",   "kv_table",  "row_to_attrs",          "what,priority,status,survive", "Focus"),
    ("OBJ",   "kv_table",  "row_to_attrs",          "goal,status,success,survive", "Objective"),
    ("WRK",   "kv_table",  "row_to_attrs",          "phase,current,blocked,survive", "Work State"),
    ("STP",   "kv_table",  "row_to_attrs",          "action,reason,owner,status,survive", "Next Step"),
    ("NXT",   "table",     "rows_to_entries",       "action,priority,trigger,status,survive", "Next Actions"),
    ("RSK",   "callout",   "callout_to_risk",       "risk,impact,mitigation,status,survive", "Risks"),
    ("AUD",   "table",     "rows_to_entries",       "event,evidence,result,date", "Audit Trail"),
    ("CLAIM", "table",     "rows_to_entries",       "statement,evidence,status", "Claims"),
    ("LIM",   "table",     "rows_to_entries",       "limit,scope,status", "Limits"),
    ("STAT",  "table",     "rows_to_entries",       "txn,result,status", "Stats"),
    ("REF",   "table",     "rows_to_entries",       "PATH,purpose", "References"),
]

# Regex for v1-style section headers like "$0: MINIMAL LOCAL GLOSSARY".
SECTION_HEADER_RE = re.compile(r'^\$(\d+)(?::\s*[^\n]*)?$', re.MULTILINE)

# Regex for entries: SIGIL:name{...}  (single-line or multiline; we only
# need the sigil to know what's present).
ENTRY_SIGIL_RE = re.compile(r'^([A-Z][A-Z0-9_]*):[A-Za-z_][A-Za-z0-9_]*\{')


def find_section_number_range(text: str) -> tuple[int, int]:
    """Return (min_section_num, max_section_num) found in ``text``."""
    nums = [int(m.group(1)) for m in SECTION_HEADER_RE.finditer(text)]
    if not nums:
        return (0, 0)
    return (min(nums), max(nums))


def find_present_sigils(text: str) -> set[str]:
    """Return the set of sigils used by entries in ``text``."""
    sigils: set[str] = set()
    for line in text.split("\n"):
        m = ENTRY_SIGIL_RE.match(line.lstrip())
        if m:
            sigils.add(m.group(1))
    sigils.discard("VIEW")  # don't count existing VIEWs
    return sigils


def find_section_for_sigil(text: str, sigil: str) -> str | None:
    """Return the section id (e.g. '$1') that contains entries of ``sigil``.

    Returns None if no such section exists.
    """
    matches = list(SECTION_HEADER_RE.finditer(text))
    if not matches:
        return None

    # Build (section_id, body_text) pairs
    sections: list[tuple[str, str]] = []
    for i, m in enumerate(matches):
        sec_num = m.group(1)
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        body = text[start:end]
        sections.append((f"${sec_num}", body))

    for sec_id, body in sections:
        for line in body.split("\n"):
            m = ENTRY_SIGIL_RE.match(line.lstrip())
            if m and m.group(1) == sigil:
                return sec_id
    return None


def build_view_directives(text: str, present_sigils: set[str]) -> list[str]:
    """Build the list of VIEW directive lines for ``text``."""
    lines: list[str] = []
    for sigil, kind, reverse, fields, title in SIGIL_VIEW_TEMPLATES:
        if sigil not in present_sigils:
            continue
        sec_id = find_section_for_sigil(text, sigil)
        if not sec_id:
            continue
        target = f'{sec_id}:{sigil}:*'
        # Build the directive line
        parts = [
            f'kind:"{kind}"',
            f'target:"{target}"',
            f'reverse:"{reverse}"',
            'status:cur',
        ]
        if fields:
            parts.append(f'fields:"{fields}"')
        parts.append(f'title:"{title}"')
        body = ",".join(parts)
        view_name = sigil.lower()
        lines.append(f'VIEW:{view_name}{{{body}}}')
    return lines


def has_views_section(text: str) -> bool:
    """Return True if ``text`` already has a section header containing 'VIEWS'."""
    for m in SECTION_HEADER_RE.finditer(text):
        line = text[m.start():m.end()]
        if "VIEW" in line.upper():
            return True
    return False


def strip_existing_views_section(text: str) -> tuple[str, bool]:
    """Remove any trailing $N: VIEWS section from ``text``.

    Returns (new_text, removed).  Only removes the LAST section if it
    contains VIEW entries.
    """
    matches = list(SECTION_HEADER_RE.finditer(text))
    if not matches:
        return text, False

    last_match = matches[-1]
    last_header_line = text[last_match.start():last_match.end()]
    if "VIEW" not in last_header_line.upper():
        return text, False

    # Strip from the start of the last section to the end of the file
    new_text = text[:last_match.start()].rstrip() + "\n"
    return new_text, True


def migrate_file(path: Path) -> bool:
    """Migrate one corpus file. Returns True if changed."""
    original = path.read_text(encoding="utf-8")

    # Remove any existing trailing VIEWS section (idempotency)
    text, _ = strip_existing_views_section(original)

    present_sigils = find_present_sigils(text)
    if not present_sigils:
        print(f"  SKIP {path.name}: no entries detected", file=sys.stderr)
        return False

    view_lines = build_view_directives(text, present_sigils)
    if not view_lines:
        print(f"  SKIP {path.name}: no VIEW directives generated", file=sys.stderr)
        return False

    _, max_sec = find_section_number_range(text)
    new_sec_num = max_sec + 1
    header = f"${new_sec_num}: VIEWS"

    # Build the new section block
    block_lines = [header, ""]
    block_lines.extend(view_lines)
    block_lines.append("")
    block = "\n".join(block_lines)

    # Append the new section. Ensure exactly one blank line between the
    # previous content and the new header.
    if not text.endswith("\n"):
        text += "\n"
    if not text.endswith("\n\n"):
        text += "\n"
    new_text = text + block

    if new_text != original:
        path.write_text(new_text, encoding="utf-8")
        return True
    return False


def main() -> int:
    if not CORPUS_DIR.is_dir():
        print(f"ERROR: corpus dir not found: {CORPUS_DIR}", file=sys.stderr)
        return 1

    cortex_files = sorted(CORPUS_DIR.glob("*.cortex"))
    if not cortex_files:
        print(f"ERROR: no .cortex files in {CORPUS_DIR}", file=sys.stderr)
        return 1

    changed = 0
    for path in cortex_files:
        print(f"  MIGRATE {path.name}")
        if migrate_file(path):
            changed += 1

    print(f"\nDone. {changed}/{len(cortex_files)} files migrated.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
