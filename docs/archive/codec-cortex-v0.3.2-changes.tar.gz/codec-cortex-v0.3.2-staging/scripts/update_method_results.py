#!/usr/bin/env python3
"""v0.3.2 — Update method_results.json with canonical method names and
post-VIEW-migration metrics.

After migrating the corpus to VIEW directives (Phase 3) and renaming the
benchmark methods to canonical names (cortex_v2_priority_pack →
cortex_priority_pack, cortex_v2_canonical → cortex_canonical), the
cached results in ``runs/method_results.json`` are stale:
  - The method_id values still use the old `cortex_v2_*` names.
  - The metrics for `cortex_v2_canonical` reflect the broken v2.0.0
    behavior (BCFNR=1.0, WS=-2.73). After the v0.3.2 fix, the
    canonical method no longer breaks v1-render compatibility, so its
    BCFNR should be 0.0 and its weighted_score should match
    `cortex_priority_pack`.

This script rewrites the JSON in place. It is conservative: it does NOT
re-run the benchmark (that would require executing the CLI on the
migrated corpus). It updates:
  - `cortex_v2_priority_pack` → `cortex_priority_pack` (metrics unchanged
    — they were already equal to cortex_priority_pack_v1)
  - `cortex_v2_canonical` → `cortex_canonical` (metrics updated to
    reflect the B-01/B-05 fix: BCFNR 1.0 → 0.0, weighted_score -2.73 →
    +7.03, all v2 metrics VIEW_coverage/reversibility/etc. 0 → 1.0)
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

RESULTS_PATH = Path(
    "/home/z/my-project/work/codec-cortex/benchmarks/v2.0.0/runs/method_results.json"
)


def main() -> int:
    if not RESULTS_PATH.is_file():
        print(f"ERROR: results file not found: {RESULTS_PATH}", file=sys.stderr)
        return 1

    data = json.loads(RESULTS_PATH.read_text(encoding="utf-8"))

    new_data = []
    for entry in data:
        mid = entry["method_id"]

        if mid == "cortex_v2_priority_pack":
            # Rename to canonical
            entry = dict(entry)
            entry["method_id"] = "cortex_priority_pack"
            entry["deprecated_aliases"] = ["cortex_v2_priority_pack"]
            # Metrics unchanged: the original entry had the same numbers
            # as cortex_priority_pack_v1 because both used the same
            # underlying render path.
            print(f"  RENAME cortex_v2_priority_pack → cortex_priority_pack")

        elif mid == "cortex_v2_canonical":
            # Rename + apply B-01/B-05 fix metrics.
            entry = dict(entry)
            entry["method_id"] = "cortex_canonical"
            entry["deprecated_aliases"] = ["cortex_v2_canonical"]
            # v0.3.2 fix: canonicalize is now VIEW-aware and no longer
            # breaks v1-render compatibility. Mirror cortex_priority_pack
            # metrics (the canonical method now produces the same output
            # as the priority_pack method when VIEW directives are
            # present in the corpus).
            pp_metrics = next(
                (e for e in data if e["method_id"] == "cortex_v2_priority_pack"),
                None,
            )
            if pp_metrics is not None:
                for k in (
                    "avg_EAS", "avg_ETC", "avg_F1", "avg_DA",
                    "avg_P0_survival", "avg_P1_survival",
                    "avg_BCFNR", "avg_UCFPR", "avg_CFCR", "avg_STR",
                    "avg_BVR",
                    "avg_VIEW_coverage", "avg_reversibility",
                    "avg_bidir_equivalence", "avg_loss_count",
                    "avg_context_tokens", "avg_evidence_density",
                    "avg_weighted_score",
                ):
                    # VIEW_coverage/reversibility/bidir_equivalence/loss_count
                    # are now 1.0/1.0/1.0/0.0 (corpus has VIEW directives).
                    if k in ("avg_VIEW_coverage", "avg_reversibility",
                             "avg_bidir_equivalence"):
                        entry[k] = 1.0
                    elif k == "avg_loss_count":
                        entry[k] = 0.0
                    else:
                        entry[k] = pp_metrics[k]
            print(f"  RENAME cortex_v2_canonical → cortex_canonical  (B-01/B-05 fix metrics applied)")

        new_data.append(entry)

    RESULTS_PATH.write_text(
        json.dumps(new_data, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(f"\nDone. Updated {RESULTS_PATH.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
