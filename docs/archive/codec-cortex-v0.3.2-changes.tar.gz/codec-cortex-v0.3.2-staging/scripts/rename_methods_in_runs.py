#!/usr/bin/env python3
"""v0.3.2 — Rename method references in benchmark run files.

Updates every JSON and CSV file under ``benchmarks/v2.0.0/runs/`` to
replace the old method ids with their canonical names:

  cortex_v2_priority_pack → cortex_priority_pack
  cortex_v2_canonical     → cortex_canonical

The numeric values are NOT recomputed (that would require re-running
the benchmark). Only the method_id strings are renamed.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

RUNS_DIR = Path(
    "/home/z/my-project/work/codec-cortex/benchmarks/v2.0.0/runs"
)

RENAMES = {
    "cortex_v2_priority_pack": "cortex_priority_pack",
    "cortex_v2_canonical": "cortex_canonical",
}


def rename_in_text(text: str) -> tuple[str, int]:
    count = 0
    for old, new in RENAMES.items():
        count += text.count(old)
        text = text.replace(old, new)
    return text, count


def main() -> int:
    if not RUNS_DIR.is_dir():
        print(f"ERROR: runs dir not found: {RUNS_DIR}", file=sys.stderr)
        return 1

    total_files = 0
    total_replacements = 0
    for path in sorted(RUNS_DIR.iterdir()):
        if not path.is_file():
            continue
        if path.suffix not in (".json", ".csv"):
            continue
        original = path.read_text(encoding="utf-8")
        new_text, count = rename_in_text(original)
        if count > 0:
            # Preserve JSON formatting
            if path.suffix == ".json":
                try:
                    data = json.loads(new_text)
                    new_text = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
                except json.JSONDecodeError:
                    # Not valid JSON — keep text-replaced version
                    pass
            path.write_text(new_text, encoding="utf-8")
            total_files += 1
            total_replacements += count
            print(f"  UPDATED {path.name}: {count} replacements")

    print(f"\nDone. {total_files} files updated, {total_replacements} total replacements.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
