#!/usr/bin/env python3
"""v0.3.2 — Recompute SHA256 hashes for the migrated corpus files.

After adding VIEW directives to each ``.cortex`` file in
``benchmarks/v2.0.0/corpus/source/``, the cached hashes in
``corpus/normalized/hashes.json`` are stale. This script recomputes the
hashes for the ``.cortex`` files only and updates the JSON in place,
preserving the hashes for the other formats (json, md, raw.md, yaml).
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

CORPUS_SOURCE = Path(
    "/home/z/my-project/work/codec-cortex/benchmarks/v2.0.0/corpus/source"
)
HASHES_PATH = Path(
    "/home/z/my-project/work/codec-cortex/benchmarks/v2.0.0/corpus/normalized/hashes.json"
)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def main() -> int:
    if not HASHES_PATH.is_file():
        print(f"ERROR: hashes.json not found: {HASHES_PATH}", file=sys.stderr)
        return 1

    data = json.loads(HASHES_PATH.read_text(encoding="utf-8"))

    cortex_files = sorted(CORPUS_SOURCE.glob("*.cortex"))
    updated = 0
    for path in cortex_files:
        key = path.name
        new_hash = sha256(path)
        old_hash = data.get(key)
        if old_hash != new_hash:
            data[key] = new_hash
            updated += 1
            print(f"  UPDATED {key}: {old_hash} -> {new_hash}")
        else:
            print(f"  OK       {key}: {new_hash}")

    HASHES_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n",
                            encoding="utf-8")
    print(f"\nDone. {updated} hashes updated.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
