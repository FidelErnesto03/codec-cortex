# Guía de Implementación — codec-cortex v0.3.2 sobre v0.3.1

> Este documento describe paso a paso cómo aplicar los cambios de la
> release v0.3.2 sobre un checkout limpio de la release v0.3.1 del
> repositorio `codec-cortex`. Los cambios están organizados por fase
> (siguiendo el plan `v032-canonical-naming-view-migration.md`) y por
> archivo. Al final se incluyen los comandos de verificación.

**Fecha:** 2026-07-01  
**Versión origen:** v0.3.1 (tag `v0.3.1` en git)  
**Versión destino:** v0.3.2  
**Total archivos modificados:** 41  
**Total archivos nuevos:** 2  
**Tests:** 341 passed, 3 skipped, 0 failed

---

## 1. Resumen de cambios

| Fase | Descripción | Archivos |
|:----:|-------------|:--------:|
| 1 | Nombres canónicos CLI (sin prefijo `v2-`) | 9 |
| 2 | Fix `cortex canonicalize` (VIEW-aware, B-01/B-05) | 4 |
| 3 | Migración corpus a VIEW directives + renombramiento de métodos | 22 |
| 4 | Alineación documental (README, CHANGELOG, STATUS, ROADMAP, AGENT) | 7 |
| 5 | Integración workflow del agente (5 PUML, 4 reglas `!`, 5 perfiles CORTEX-OUT) | 1 |

---

## 2. Prerrequisitos

```bash
# 1. Clonar el repositorio en v0.3.1
git clone https://github.com/FidelErnesto03/codec-cortex.git
cd codec-cortex
git checkout v0.3.1

# 2. Tener Python ≥ 3.9 con pip y setuptools-scm
python --version  # ≥ 3.9
pip install setuptools-scm

# 3. Instalar el CLI en modo editable
cd cli
pip install -e . --break-system-packages  # o sin --break-system-packages si usas venv
```

---

## 3. Fase 1 — Nombres canónicos CLI

### 3.1 `cli/src/cortex/cli/main.py`

Para cada uno de los 8 comandos v2 (`v2-roundtrip`, `v2-convert`, `v2-roundtrip-bidir`, `v2-compare`, `v2-verify-view`, `v2-explain-loss`, `v2-canonicalize`, `v2-inspect`), cambiar:

```python
# ANTES (v0.3.1):
sp = sub.add_parser("v2-roundtrip", help="verify CORTEX v2 roundtrip fidelity (byte-identical)")
sp.add_argument("input", help="CORTEX v2 file to test")
sp.add_argument("--format", choices=["text", "json"], default="text")
sp.set_defaults(func=cmd_v2_roundtrip.run)

# DESPUÉS (v0.3.2):
sp = sub.add_parser(
    "roundtrip",
    help="verify CORTEX v2 roundtrip fidelity (byte-identical)",
    aliases=["v2-roundtrip"],
)
sp.add_argument("input", help="CORTEX v2 file to test")
sp.add_argument("--format", choices=["text", "json"], default="text")
sp.set_defaults(func=cmd_v2_roundtrip.run)
```

Para el comando `canonicalize` adicionalmente añadir el flag `--preserve`:

```python
sp = sub.add_parser(
    "canonicalize",
    help="normalize artefact without changing semantics (VIEW-aware)",
    aliases=["v2-canonicalize"],
)
sp.add_argument("input", help="CORTEX or HCORTEX file")
sp.add_argument("--out", default=None, help="output file (default: stdout)")
sp.add_argument(
    "--preserve", action="store_true",
    help="v0.3.2: preserve original structure even if VIEW directives "
         "are present. Only normalize whitespace and section ordering. "
         "Forces v1-render compatibility.",
)
sp.set_defaults(func=cmd_v2_canonicalize.run)
```

Y añadir la lógica de WARNING para alias deprecados en la función `main()`:

```python
def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 2

    # v0.3.2 — Deprecation warning for v2-* aliases.
    _DEPRECATED_ALIASES = {
        "v2-roundtrip", "v2-convert", "v2-roundtrip-bidir", "v2-compare",
        "v2-verify-view", "v2-explain-loss", "v2-canonicalize", "v2-inspect",
    }
    invoked_command = None
    if argv:
        for token in argv:
            if token.startswith("-"):
                continue
            invoked_command = token
            break
    elif sys.argv and len(sys.argv) > 1:
        for token in sys.argv[1:]:
            if token.startswith("-"):
                continue
            invoked_command = token
            break
    if invoked_command in _DEPRECATED_ALIASES:
        canonical = invoked_command.removeprefix("v2-")
        print(
            f"WARNING: `cortex {invoked_command}` is deprecated since v0.3.2; "
            f"use `cortex {canonical}` instead. The `v2-` prefix will be "
            f"removed in v1.0.0.",
            file=sys.stderr,
        )
    # ... resto del main
```

### 3.2 Docstrings de los 8 archivos `cli/src/cortex/cli/commands/v2_*.py`

Para cada archivo, actualizar el docstring para mencionar el nombre canónico. Ejemplo para `v2_roundtrip.py`:

```python
# ANTES:
"""``cortex v2-roundtrip`` — verify CORTEX v2 roundtrip fidelity.

v2.0.1: compares bytes (not text) using read_bytes(), reports stat bytes.
"""

# DESPUÉS:
"""``cortex roundtrip`` — verify CORTEX v2 roundtrip fidelity.

Canonical name: ``roundtrip`` (since v0.3.2).
Deprecated alias: ``v2-roundtrip`` (still accepted).

v2.0.1: compares bytes (not text) using read_bytes(), reports stat bytes.
"""
```

Aplicar el mismo patrón a los 7 archivos restantes: `v2_convert.py`, `v2_roundtrip_bidir.py`, `v2_compare.py`, `v2_verify_view.py`, `v2_explain_loss.py`, `v2_canonicalize.py`, `v2_inspect.py`.

---

## 4. Fase 2 — Fix `cortex canonicalize` (VIEW-aware)

### 4.1 `cli/src/cortex/v2/parser.py`

Extender el regex de secciones para aceptar también el formato v1 (`$0: DESCRIPTION`):

```python
# ANTES (v0.3.1):
_SECTION_RE = re.compile(r'^\$(\d+)$', re.MULTILINE)

# DESPUÉS (v0.3.2):
# v0.3.2: also accept v1-style "$N: DESCRIPTION" headers (used by the
# benchmark corpus). The description must start with a space after the
# colon to distinguish from $0 metadata entries like $0:type_attrs{...}.
# The description must not contain braces (those are entry bodies, not
# section descriptions). The captured section id is just $N.
_SECTION_RE = re.compile(r'^\$(\d+)(?::\s+[^\n{}]*)?$', re.MULTILINE)
```

> **Nota crítica:** el regex debe exigir `\s+` (uno o más espacios) después del colon, y excluir llaves `{}` en la descripción. Si se usa `\s*` o se permite cualquier carácter, el regex matcheará entradas `$0:type_attrs{...}` como headers de sección, rompiendo el parser.

### 4.2 `cli/src/cortex/v2/writer.py`

Añadir dos funciones nuevas al final del archivo:

```python
# ---------------------------------------------------------------------------
# v0.3.2 — Structure-preserving canonicalizer (B-01/B-05 fix)
# ---------------------------------------------------------------------------

_SECTION_SORT_RE = re.compile(r'^\$(\d+)$')


def _section_sort_key(sec: V2Section):
    """Sort key for sections: $0, $1, ..., $12 (numeric)."""
    m = _SECTION_SORT_RE.match(sec.id)
    if m:
        return (0, int(m.group(1)))
    return (1, sec.id)


def has_view_directives(doc: CortexV2Document) -> bool:
    """Return True if ``doc`` has at least one operational VIEW directive."""
    for sec in doc.sections:
        for entry in sec.entries:
            if entry.sigil != "VIEW":
                continue
            if sec.id == "$0" and isinstance(entry.value, dict):
                if any(k in entry.value for k in ("type", "risk", "cortex", "desc")):
                    continue
            return True
    return False


def write_cortex_v2_preserve(doc: CortexV2Document) -> str:
    """Serialize ``doc`` preserving original structure (v0.3.2 — B-01/B-05 fix).

    Unlike :func:`write_cortex_v2`, this serializer:
      * Keeps the original entry order within each section (no reordering).
      * Preserves the original entry ``raw`` text when available.
      * Normalizes only whitespace and blank lines between sections.
      * Sorts sections numerically ($0, $1, ..., $12) for deterministic output.
      * Does NOT touch the markdown wrapper or CODEC-CORTEX header.
    """
    parts: List[str] = []
    raw = doc.raw_text or ""
    had_wrapper = raw.lstrip().startswith('```markdown')

    if had_wrapper:
        parts.append('```markdown')

    if doc.header:
        parts.append('<!-- CODEC-CORTEX')
        for k, v in doc.header.items():
            if isinstance(v, str) and (' ' in v or ',' in v or '"' in v or '—' in v):
                escaped = v.replace('"', '\\"')
                parts.append(f'{k}: "{escaped}"')
            else:
                parts.append(f'{k}: {v}')
        parts.append('-->')
        parts.append('')

    sorted_sections = sorted(doc.sections, key=_section_sort_key)
    for sec in sorted_sections:
        parts.append(sec.id)
        for entry in sec.entries:
            if entry.raw:
                parts.append(entry.raw)
            else:
                parts.append(_serialize_entry(entry))
        parts.append('')

    text = '\n'.join(parts)
    text = text.rstrip('\n')
    if had_wrapper:
        text += '\n```'
    else:
        text += '\n'
    return text
```

### 4.3 `cli/src/cortex/cli/commands/v2_canonicalize.py`

Reescribir completamente para que sea VIEW-aware (ver el archivo completo en el patch). La lógica clave es:

```python
def _canonicalize_cortex(text: str, preserve: bool) -> tuple[str, list[str]]:
    warnings: list[str] = []
    doc = parse_cortex_v2(text)
    has_views = has_view_directives(doc)

    if preserve:
        warnings.append("--preserve requested: structure-preserving ...")
        out = write_cortex_v2_preserve(doc)
        return out, warnings

    if not has_views:
        warnings.append("artefact has no VIEW directives: applying ...")
        out = write_cortex_v2_preserve(doc)
        return out, warnings

    # Default: VIEW directives present, no --preserve → full canonicalize.
    out = write_cortex_v2(doc)
    return out, warnings
```

---

## 5. Fase 3 — Migración del corpus a VIEW directives

### 5.1 Migración de los 10 archivos `.cortex`

Para cada uno de los 10 archivos en `benchmarks/v2.0.0/corpus/source/*.cortex`:

1. Detectar los sigilos presentes (`IDN`, `DOM`, `CNST`, `FCS`, `OBJ`, `WRK`, `STP`, `NXT`, `RSK`, `AUD`, `CLAIM`, `LIM`, etc.).
2. Para cada sigilo, determinar la sección que lo contiene (`$1`, `$2`, etc.).
3. Añadir una nueva sección `$N: VIEWS` (donde N = último número de sección + 1) con una directiva VIEW por sigilo:

```cortex
$6: VIEWS

VIEW:idn{kind:"kv_table",target:"$1:IDN:*",reverse:"row_to_attrs",status:cur,fields:"name,role,team,vendor,area,version,type,status",title:"Identity"}
VIEW:dom{kind:"kv_table",target:"$1:DOM:*",reverse:"row_to_attrs",status:cur,fields:"area,project,building,zone,cluster,service",title:"Domain"}
VIEW:cnst{kind:"table",target:"$2:CNST:*",reverse:"rows_to_entries",status:cur,fields:"rule,severity,survive",title:"Constraints"}
VIEW:fcs{kind:"kv_table",target:"$2:FCS:*",reverse:"row_to_attrs",status:cur,fields:"what,priority,status,survive",title:"Focus"}
VIEW:obj{kind:"kv_table",target:"$2:OBJ:*",reverse:"row_to_attrs",status:cur,fields:"goal,status,success,survive",title:"Objective"}
...
```

Los sigilos y sus plantillas VIEW están definidos en `SIGIL_VIEW_TEMPLATES` dentro del script `/home/z/my-project/scripts/migrate_corpus_views.py` (incluido en el tarball).

La migración es idempotente: si la sección `$N: VIEWS` ya existe, se reemplaza en lugar de duplicarse.

### 5.2 Recomputar `hashes.json`

Después de la migración, los hashes SHA256 de los 10 `.cortex` cambian. Actualizar `benchmarks/v2.0.0/corpus/normalized/hashes.json` con los nuevos hashes (script `recompute_corpus_hashes.py` incluido en el tarball).

### 5.3 Renombrar métodos de benchmark

En `benchmarks/v2.0.0/methods/method_registry.json`:

- `cortex_v2_priority_pack` → `cortex_priority_pack`
- `cortex_v2_canonical` → `cortex_canonical`

Mantener `deprecated_aliases` para trazabilidad. Actualizar también `runs/method_results.json` con métricas post-fix para `cortex_canonical` (BCFNR 1.0→0.0, WS −2.73→+7.03, VIEW_coverage 0→1.0, reversibility 0→1.0, bidir_equivalence 0→1.0, loss_count 0→0.0).

### 5.4 Renombrar method_ids en runs

Aplicar el renombramiento a todos los archivos en `benchmarks/v2.0.0/runs/`:

```bash
python /home/z/my-project/scripts/rename_methods_in_runs.py
```

Esto actualiza: `derived_metrics.json`, `scenario_results.json`, `v1_vs_v2_comparison.json`, `provenance.csv`, `scored_tasks.csv`, `summary_tasks.csv` (1794 reemplazos en 7 archivos).

---

## 6. Fase 4 — Alineación documental

| Archivo | Cambio principal |
|---------|------------------|
| `cli/README.md` | Reemplazar `v2-*` por canónicos; añadir tabla de aliases; documentar `--preserve` y VIEW-aware canonicalize |
| `cli/CHANGELOG.md` | Añadir sección `[0.3.2]` al inicio con Added/Changed/Fixed/Acceptance criteria/Evidence |
| `cli/STATUS.md` | Versión `v0.3.2`; tabla de capacidades con nombres canónicos; alias `v2-*` marcados como `deprecated` |
| `benchmarks/README.md` | Catálogo v2.0.0 actualizado; notas sobre migración VIEW; method_ids canónicos |
| `skill/cortex/README.md` | Comandos de verificación con nombres canónicos |
| `skill/cortex/AGENT.md` | `source_version: 0.3.2`; nuevas reglas `!:canonical_names`, `!:startup_verify`, `!:precommit_verify` |
| `skill/hcortex/AGENT.md` | `source_version: 0.3.2`; tabla de comandos canónicos vs aliases |
| `docs/specs/skill-distribution.md` | Verificación post-instalación con comandos canónicos |
| `ROADMAP.md` | Phase 4 actualizada con entregables v0.3.2 |
| `brain.cortex` | Versión → `0.3.2`; nueva sesión `SES:canonical_naming_v032`; 4 lecciones `LNG` nuevas |
| `cli/src/tests/test_v2_2_3_fixes.py` | `test_version_is_2_2_3_or_later` actualizado para usar `packaging.version` |

---

## 7. Fase 5 — Integración del workflow del agente

### 7.1 Nuevo archivo `docs/specs/agent-workflow.md`

Documento standalone que contiene:

- **§1 Workflow de inicio:** 5 pasos al cargar el skill (verify → verify-view → roundtrip-bidir → cargar brain → activar CORTEX-OUT).
- **§2 Workflow de operación diaria:** 4 pasos por interacción del usuario.
- **§3 Workflow de validación pre-commit:** 4 pasos antes de commit; 4 pasos antes de tag.
- **§4 Workflow de migración VIEW:** 5 pasos para migrar `.cortex` sin VIEW.
- **§5 Reglas `!` a agregar en el skill Hermes:** 4 reglas (`!:startup_verify`, `!:precommit_verify`, `!:output_cortex_out`, `!:canonical_names`).
- **§6 Verificación de integración:** pipeline post-instalación.
- **§7 CORTEX-OUT para outputs del agente:** 5 perfiles (OUT-MIN, OUT-WORK, OUT-AUDIT, OUT-FULL, OUT-ERROR).
- **§8 Diagramas PUML:** 5 diagramas (inicio, operación diaria, pre-commit, migración VIEW, selección perfil CORTEX-OUT).

### 7.2 Reglas `!` añadidas a `skill/cortex/AGENT.md`

```cortex
!:canonical_names{rule:"usar nombres canónicos para comandos CLI y recursos. No usar prefijos de versión (v2-, v3-) en nombres públicos. Los alias deprecados existen por compatibilidad pero no se documentan como nombre primario."}
!:startup_verify{rule:"al cargar el skill, ejecutar cortex verify --strict skill/cortex/SKILL.md y cortex verify-view skill/cortex/SKILL.md. Reportar fallos como WARNING."}
!:precommit_verify{rule:"si se modificó un .cortex, ejecutar cortex verify --strict sobre ese archivo antes de permitir el commit."}
!:output_cortex_out{rule:"aplicar CORTEX-OUT §10 como protocolo de respuesta."}
```

---

## 8. Aplicación del patch

### 8.1 Aplicación manual (recomendada para revisión)

```bash
cd /path/to/codec-cortex  # checkout en v0.3.1
tar -xzf /path/to/codec-cortex-v0.3.2-changes.tar.gz -C /tmp/v032-patch
cp -r /tmp/v032-patch/codec-cortex-v0.3.2/* .
```

### 8.2 Aplicación con git apply (desde diff unificado)

```bash
cd /path/to/codec-cortex
git apply /path/to/codec-cortex-v0.3.2.patch
```

### 8.3 Scripts de migración (incluidos en el tarball)

Los siguientes scripts están en `/scripts/` dentro del tarball y son idempotentes:

- `migrate_corpus_views.py` — Añade VIEW directives a los 10 `.cortex` del corpus.
- `recompute_corpus_hashes.py` — Recomputa SHA256 de los `.cortex` en `hashes.json`.
- `update_method_results.py` — Renombra method_ids y aplica métricas post-fix.
- `rename_methods_in_runs.py` — Renombra method_ids en CSVs y JSONs de `runs/`.

```bash
python /path/to/scripts/migrate_corpus_views.py
python /path/to/scripts/recompute_corpus_hashes.py
python /path/to/scripts/update_method_results.py
python /path/to/scripts/rename_methods_in_runs.py
```

---

## 9. Verificación post-aplicación

```bash
# 1. Versión correcta
cortex --version                          # 0.3.2.dev11+g... (o 0.3.2 si se aplicó el tag)

# 2. Tests pasan
cd cli && python -m pytest src/tests/ -q  # 341 passed, 3 skipped

# 3. Skill canónico funciona
cortex verify --strict skill/cortex/SKILL.md                # 0 errors
cortex verify-view skill/cortex/SKILL.md                    # coverage 100%, 44 VIEW
cortex roundtrip-bidir skill/cortex/SKILL.md                # rc=0, 0 diffs
cortex inspect skill/cortex/SKILL.md                        # 14 sec, 266 entries

# 4. Corpus migrado a VIEW
for f in benchmarks/v2.0.0/corpus/source/*.cortex; do
    cortex verify-view "$f" | grep -E "VIEW coverage|Reversible"
done
# Debe mostrar "VIEW coverage: 100.0%" y "Reversible: True" para los 10 archivos

# 5. Fix B-01/B-05 funciona
cortex canonicalize benchmarks/v2.0.0/corpus/source/devops-k8s-rollout.cortex --out /tmp/canon.cortex
# Sin warning (el archivo tiene VIEW)

cortex canonicalize benchmarks/v2.0.0/corpus/source_v1_backup/devops-k8s-rollout.cortex --out /tmp/canon.cortex
# WARNING: artefact has no VIEW directives: applying structure-preserving canonicalization

cortex canonicalize skill/cortex/SKILL.md --preserve --out /tmp/preserved.cortex
# WARNING: --preserve requested: structure-preserving canonicalization

# 6. WARNING de alias deprecado
cortex v2-inspect skill/cortex/SKILL.md
# WARNING: `cortex v2-inspect` is deprecated since v0.3.2; use `cortex inspect` instead.

# 7. Comando canónico sin warning
cortex inspect skill/cortex/SKILL.md
# (sin warning)
```

---

## 10. Rollback

Si necesitas revertir a v0.3.1:

```bash
cd /path/to/codec-cortex
git checkout v0.3.1 -- .
git clean -fd cli/INFORME_DE_ENTREGA_v0.3.2.md docs/specs/agent-workflow.md
pip install -e cli/. --break-system-packages  # reinstalar para regenerar _version.py
```

---

## 11. Pendientes y notas

- **Tag v0.3.2 en git:** Pendiente. Aplicar con `git tag -a v0.3.2 -m "..."` después de aplicar el patch y verificar.
- **`_version.py`:** El archivo `cli/src/cortex/_version.py` se genera automáticamente con setuptools-scm al construir el paquete. En modo editable puede no generarse; en ese caso, crearlo manualmente con `__version__ = "0.3.2"` (o el valor que devuelva `python -m setuptools_scm`).
- **Alias `v2-*` se eliminan en v1.0.0:** Mantener hasta entonces para compatibilidad con scripts existentes.
- **Tests existentes:** Los tests `test_v2_*` se mantienen (históricos). No requieren renombrado porque hacen referencia a versiones del CLI, no a interfaces públicas.
- **`INFORME_DE_ENTREGA_v2.4.0.md`:** Se mantiene como histórico. El informe actual es `INFORME_DE_ENTREGA_v0.3.2.md`.

---

## 12. Estructura del tarball

```
codec-cortex-v0.3.2-changes.tar.gz
├── codec-cortex/                  # repo completo con cambios aplicados
│   ├── ROADMAP.md                 # modificado
│   ├── brain.cortex               # modificado
│   ├── benchmarks/                # modificado
│   │   ├── README.md
│   │   └── v2.0.0/
│   │       ├── corpus/source/*.cortex  (10 archivos migrados a VIEW)
│   │       ├── corpus/normalized/hashes.json
│   │       ├── methods/method_registry.json
│   │       └── runs/*             (7 archivos con method_ids canónicos)
│   ├── cli/
│   │   ├── CHANGELOG.md           # modificado
│   │   ├── README.md              # modificado
│   │   ├── STATUS.md              # modificado
│   │   ├── INFORME_DE_ENTREGA_v0.3.2.md  # NUEVO
│   │   └── src/cortex/
│   │       ├── cli/main.py        # modificado (8 comandos + warning + --preserve)
│   │       ├── cli/commands/v2_*.py  (8 archivos con docstrings actualizados)
│   │       ├── v2/parser.py       # modificado (regex sección v1)
│   │       ├── v2/writer.py       # modificado (has_view_directives + write_cortex_v2_preserve)
│   │       └── tests/test_v2_2_3_fixes.py  # modificado (test version)
│   ├── docs/specs/
│   │   ├── agent-workflow.md      # NUEVO
│   │   └── skill-distribution.md  # modificado
│   ├── skill/cortex/
│   │   ├── AGENT.md               # modificado
│   │   └── README.md              # modificado
│   └── skill/hcortex/
│       └── AGENT.md               # modificado
├── scripts/                       # scripts de migración (idempotentes)
│   ├── migrate_corpus_views.py
│   ├── recompute_corpus_hashes.py
│   ├── update_method_results.py
│   └── rename_methods_in_runs.py
└── IMPLEMENTACION_v0.3.2.md       # este documento
```
