# Alineación de `docs/` con v0.3.5 — Resumen de cambios

**Fecha:** 2026-07-02 (revisión 2 — auditoría profunda de `docs/specs/`)
**Versión del proyecto:** 0.3.5 (E3 — Protocolo de Documentación)
**Commit base:** `70c620659e4fffad848dc1b5b0311c560062070a`

Este paquete contiene la carpeta `docs/` del repositorio `codec-cortex` con
correcciones de alineación a v0.3.5. Los fundamentos, principios y diseño
arquitectónico del protocolo **no fueron modificados** — sólo se actualizaron
versiones, status notes, referencias operativas y workflow para reflejar la
realidad actual del proyecto (E1 v0.3.3, E2 v0.3.4, E3 v0.3.5).

## Archivos modificados (15)

### 🔴 Correcciones críticas de versión

| Archivo | Cambio |
|---------|--------|
| `docs/specs/agent-workflow.md` | `(v0.3.2)` → `(v0.3.5)` en título; `≥ 0.3.2` → `≥ 0.3.5` en pipeline post-instalación; filtro de grep de release extendido para `[0.3.4]` y `[0.3.5]` |
| `docs/specs/skill-distribution.md` | `# v0.3.4` → `# v0.3.5`; `version = "0.3.4"` → `version = "0.3.5"` en pyproject de ejemplo |
| `docs/cortex/api/canonicalize.cortex` | `requires: "cortex 0.3.2+"` → `requires: "cortex 0.3.5+"` |
| `docs/cortex/api/convert.cortex` | `requires: "cortex 0.3.2+"` → `requires: "cortex 0.3.5+"` |
| `docs/cortex/api/verify.cortex` | `requires: "cortex 0.3.2+"` → `requires: "cortex 0.3.5+"` |

### 🟠 Auditoría profunda de `docs/specs/` (revisión 2)

| Archivo | Cambio |
|---------|--------|
| `docs/specs/skill-distribution.md` | Header: `Versión: 1.0-draft · 2026-06-27` → `1.1 · alineada a proyecto v0.3.5 · 2026-07-01` + NOTA DE ESTADO. §7: `Inspección v2` → `Inspección` (eliminada mención al prefijo v2). §8: renombrado de "Distribución futura (PyPI)" → "Distribución vía PyPI (actual desde v0.3.3)"; "Instalación futura" → "Instalación"; añadidos ejemplos de `cortex doctor --scan-secrets`, `cortex docstring`, `cortex benchmark`. |
| `docs/specs/context-survival.md` | Header: añadido `v0.3.5` al subtítulo. Tabla metadata: `specification draft` → `v0.3.5 (conceptos implementados en CLI; benchmark automatizado planeado)`. Añadida NOTA DE ESTADO declarando que survive/P0-P5/perfiles/degradación/HCORTEX están implementados en CLI. §6: actualizada la frase "no pretende ser una medición automatizada hasta que exista parser" → "el parser determinista y el CLI ya existen — la métrica sigue siendo conceptual en tanto no se publiquen suites automatizadas". |
| `docs/specs/benchmark-methodology.md` | Header: añadido `v0.3.5` al subtítulo. Tabla metadata: `specification draft` → `v0.3.5 (methodology; suites v1.0.0 / v2.0.0 / v2.1.0 publicadas)`. Añadida NOTA DE ESTADO mencionando parser, CLI y `cortex benchmark` implementados. §5: tabla de benchmarks expandida para listar las suites científicas v1.0.0, v2.0.0 y v2.1.0 (4,840 runs cada una) como publicadas; 0.1/0.1b/0.2 marcadas como "referencia histórica". Última línea actualizada: ya no dice "La automatización requiere parser. La metodología aquí definida será aplicable cuando exista codec." |
| `docs/specs/agent-workflow.md` | §3 pre-commit workflow: añadido paso `cortex doctor --scan-secrets` (E2). §3 pre-tag workflow: añadidos pasos `cortex verify --signature` (E2), `cortex docstring --all` (E3) y `cortex benchmark --list` (E3). §5 reglas `!`: añadidas `!:mutation_mode` (E2), `!:docs_source_of_truth` (E3) y `!:secret_scan` (E2). |

### 🟡 Status notes actualizadas (mencionan E2/E3 y v0.3.5)

| Archivo | Cambio |
|---------|--------|
| `docs/en/specs/fundamentals.md` | Status note ampliada: menciona CLI con comandos canónicos, E2 (security), E3 (docs) |
| `docs/en/specs/algorithm.md` | Status note ampliada: menciona canonical names, E2, E3 |
| `docs/en/specs/adoption.md` | Status note ampliada: menciona PyPI, E2, E3; enterprise MCP como future phase |
| `docs/en/specs/mcp-bridge.md` | Status note ampliada: handler map es design contract para futuro MCP |
| `docs/es/specs/fundamentos.md` | Equivalente ES de fundamentals.md |
| `docs/es/specs/algoritmo.md` | Equivalente ES de algorithm.md |
| `docs/es/specs/adopcion.md` | Equivalente ES de adoption.md |
| `docs/es/specs/aprendizaje.md` | Status note ampliada: menciona CLI con E2/E3 actuales; runtime sigue futuro |
| `docs/es/specs/mcp-bridge.md` | Equivalente ES de mcp-bridge.md |

### 🟢 Archivo histórico anotado

| Archivo | Cambio |
|---------|--------|
| `docs/review/project-reorientation-report.md` | Añadida NOTA EDITORIAL al inicio declarando el carácter histórico del reporte. Contenido original preservado íntegro. |

## Archivos NO modificados (verificados alineados)

- `docs/README.md`
- `docs/hcortex/tutorials/getting-started.md`
- `docs/hcortex/how-to/derive-docstrings.md`
- `docs/hcortex/explanations/documentation-protocol.md`
- `docs/hcortex/reference/README.md`
- `docs/cortex/api/README.md`
- `docs/cortex/api/docstring.cortex` (ya v0.3.5+)
- `docs/cortex/api/benchmark.cortex` (ya v0.3.5+)
- `docs/cortex/api/doctor.cortex` (correcto: `requires: cortex 0.3.4+` — comando introducido en E2)
- `docs/cortex/api/audit.cortex` (correcto: `requires: cortex 0.3.4+` — comando introducido en E2)
- `docs/cortex/api/modes.cortex` (correcto: `requires: cortex 0.3.4+` — comando introducido en E2)
- `docs/cortex/specs/documentation-protocol.cortex` (ya v0.3.5+)

## ⚠️ Hallazgos fuera del alcance de `docs/`

Durante la auditoría profunda de `docs/specs/` se detectaron referencias stale
en `skill/` que **no se modificaron** porque el alcance original era `docs/`.
Se listan aquí para que el usuario decida si extender el alcance:

| Archivo | Línea | Actual | Debería ser |
|---------|:-----:|--------|-------------|
| `skill/cortex/SKILL.md` | 92 | `project:"0.3.2"` | `project:"0.3.5"` |
| `skill/cortex/AGENT.md` | 4 | `source_version: 0.3.2` | `source_version: 0.3.5` |
| `skill/cortex/AGENT.md` | 27 | `version:"0.3.2"` | `version:"0.3.5"` |
| `skill/cortex/AGENT.md` | 41 | `operate v0.3.2 with CLI v0.3.2` | `operate v0.3.5 with CLI v0.3.5` |
| `skill/cortex/AGENT.md` | 43 | `alineado a v0.3.2` | `alineado a v0.3.5` |
| `skill/cortex/AGENT.md` | 55 | `sección [0.3.2] актуальна` | `sección [0.3.5] актуальна` |
| `skill/cortex/README.md` | 49 | `v0.3.4 — canonical command names` | `v0.3.5 — canonical command names` |
| `skill/cortex/README.md` | 57 | `v0.3.4 — Naming canónico` | `v0.3.5 — Naming canónico` |
| `skill/hcortex/SKILL_HCORTEX.md` | 13 | `project 0.3.2` | `project 0.3.5` |
| `skill/hcortex/SKILL.md` | 234 | `project \| 0.3.0` | `project \| 0.3.5` |
| `skill/hcortex/AGENT.md` | 4 | `source_version: 0.3.2` | `source_version: 0.3.5` |
| `skill/hcortex/AGENT.md` | 18 | `Versión del protocolo \| 0.3.2` | `Versión del protocolo \| 0.3.5` |
| `skill/hcortex/AGENT.md` | 45 | `Desde v0.3.2` | `Desde v0.3.2` (correcto — histórico) |
| `skill/hcortex/AGENT.md` | 51 | `Operación v0.3.2 — CLI v0.3.2` | `Operación v0.3.5 — CLI v0.3.5` |
| `skill/hcortex/AGENT.md` | 55 | `Comandos CLI canónicos (v0.3.2)` | `Comandos CLI canónicos (v0.3.5)` |
| `skill/hcortex/AGENT.md` | 78 | `sección [0.3.2] актуальна` | `sección [0.3.5] актуальна` |

> Nota: las menciones "Desde v0.3.2" en contexto histórico (cuándo se introdujo
> una característica) son correctas y no deben cambiarse.

## Principios preservados

1. **No tergiversar fundamentos:** los axiomas, la ontología cognitiva, el
   algoritmo determinista, las ecuaciones de densidad y el contrato del
   protocolo HCORTEX no fueron alterados.
2. **No sobre-claim:** Runtime y MCP siguen marcados como planned/future.
   El status note de cada spec lo refleja explícitamente.
3. **Coherencia con STATUS.md y CHANGELOG.md:** las status notes ahora
   mencionan E2 (security & governance, v0.3.4) y E3 (documentation protocol,
   v0.3.5) como implementados, alineando con `cli/CHANGELOG.md`.
4. **`requires` como versión mínima:** doctor/audit/modes mantienen `0.3.4+`
   porque esos comandos surgieron en E2; canonicalize/convert/verify pasan a
   `0.3.5+` porque la API doc structure y `cortex docstring` que los consume
   surgieron en E3.
5. **Distinción histórico vs actual:** las menciones tipo "introducido en
   v0.3.X" se preservan; sólo se actualizan las menciones del estado actual
   del proyecto.

## Cómo aplicar

### Opción A — Reemplazo directo

```bash
tar -xzf codec-cortex-docs-v0.3.5-aligned.tar.gz
# Reemplaza docs/ en tu working copy del repo
cp -r codec-cortex-docs-v0.3.5-aligned/docs/ /path/to/codec-cortex/docs/
```

### Opción B — Aplicar el patch

```bash
cd /path/to/codec-cortex
git apply docs-align-v0.3.5.patch
```

## Validación post-aplicación

```bash
# 1. Verificar que no quedan versiones stale en docs/
rg "0\.3\.[0-4]\+" docs/cortex/api/  # debe estar vacío
rg "v0\.3\.[0-4]\b" docs/specs/      # debe estar vacío
rg "specification draft" docs/specs/ # debe estar vacío
rg "Distribución futura|Instalación futura" docs/specs/  # debe estar vacío

# 2. Validar archivos .cortex
cortex verify --strict docs/cortex/api/canonicalize.cortex
cortex verify --strict docs/cortex/api/convert.cortex
cortex verify --strict docs/cortex/api/verify.cortex
cortex verify --strict docs/cortex/specs/documentation-protocol.cortex

# 3. Generar docstrings desde la fuente actualizada
cortex docstring --all

# 4. Verificar que las status notes mencionan v0.3.5
rg "NOTA DE ESTADO|STATUS NOTE" docs/ | grep "v0.3.5"
```
