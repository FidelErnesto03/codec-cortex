# Patch Summary — CODEC-CORTEX Learning Engine v0.2.0

**Date:** 2026-07-02
**Evolution document:** `learning-engine-evolution.md` (Fases A–E)
**Baseline:** v0.1.0 (`CODEC_CORTEX_LEARNING_ENGINE_SPEC.md`)
**Target project:** https://github.com/FidelErnesto03/codec-cortex (commit `9999399`, v0.3.6)
**Engine version:** 0.2.0
**Algorithm:** `golden_fibonacci_v1`

---

## 1. What changed since v0.1.0

v0.2.0 implements the five evolution fases defined in `learning-engine-evolution.md` (§A through §E). Fase G (MCP server) is explicitly **excluded** from this release per the user's request.

| Fase | Feature | New module(s) | New CLI commands |
|:----:|---|---|---|
| **A** | Ciclo de sesión | `session.py`, `session_cli.py` | `cortex session start/status/consolidate/close` |
| **B** | Auto-detección en handlers | `handlers.py` | `cortex learn pre-action/post-action` |
| **C** | Decay y enfriamiento | `decay.py` | Automatic on `session close` |
| **D** | Feedback loop | `feedback.py` | `cortex learn feedback/feedback-show` |
| **E** | Thresholds configurables | (extends `policy.py`, `policy_defaults.py`) | `cortex learn policy set/profile/reset` |

---

## 2. Files created

### 2.1 New modules in `cortex/learning/`

| File | Lines | Purpose |
|---|---:|---|
| `session.py` | 505 | Session lifecycle: start, status, consolidate, close. Persists `SES:current` and `SES:last` in `brain.cortex`; cache in `.cortex/cache/session.json`. |
| `session_cli.py` | 175 | Argparse integration for `cortex session` subcommand. |
| `handlers.py` | 290 | `pre_action` (theme detection) and `post_action` (candidate notification) entry points. |
| `decay.py` | 245 | `cooling_factor(days, half_life)` + `apply_decay_to_index(idx, ps, now, brain_doc)`. Honors `survive:"min"` / `survive:"recovery"` / protected-pattern / structural-sigil exemptions. |
| `feedback.py` | 265 | `FeedbackRecord` / `FeedbackHistory` + `record_feedback` + `adjust_thresholds`. Cache in `.cortex/cache/feedback.json`. |
| **Total new** | **1 480** | |

### 2.2 Modified modules in `cortex/learning/`

| File | Change | Lines added |
|---|---|---:|
| `__init__.py` | Bumped `ENGINE_VERSION` to `0.2.0`; added module docstring entries for the 4 new modules. | +12 |
| `errors.py` | Added `LE014_SESSION_ALREADY_RUNNING`, `LE015_SESSION_NOT_RUNNING`, `LE016_FEEDBACK_RECORD_NOT_FOUND`, `LE017_UNKNOWN_PROFILE`. | +20 |
| `policy.py` | Added 5 new dataclasses (`FibonacciThresholds`, `CoolingPolicy`, `DetectionPolicy`, `FeedbackPolicy`, `ProtectedPatterns`); extended `LearningPolicySet` with 6 new fields; extended `_handle_policy` to recognise config-block entries; added `effective_threshold` / `record_adjusted_threshold` / `is_protected_pattern` helpers. | +200 |
| `policy_defaults.py` | Extended default policy text with the 5 new `POL:*` config blocks; added `aggressive_policy_text`, `conservative_policy_text`, `PROFILES` registry. | +90 |
| `scoring.py` | Added `last_accessed: str = ""` field to `ScoreRecord` (for decay tracking); updated `to_dict()` to emit it conditionally. | +15 |
| `index.py` | Updated `LearnIndex.from_dict` to load `last_accessed`; updated `rebuild_index` to accept `previous_index` and preserve `last_accessed`; updated `rebuild_for_workspace` to pass the previous index. | +30 |
| `cli.py` | Added subparsers for `policy set/profile/reset`, `feedback`, `feedback-show`, `pre-action`, `post-action`, `index rebuild --if-stale`; added 7 new command handlers. | +250 |
| `workspace.py` | (Unchanged in functionality; minor docstring updates.) | 0 |
| **Total modified** | | **+617** |

### 2.3 Tests

| File | Tests | Coverage |
|---|---:|---|
| `tests/test_learning_engine.py` | 49 | v0.1.0 baseline (unchanged) |
| `tests/test_learning_engine_v02.py` | 47 | v0.2.0: A, B, C, D, E + integration + CLI + forbidden patterns + backwards compat |
| **Total** | **96** | |

### 2.4 Templates

| File | Change |
|---|---|
| `templates/.cortex/MANIFEST.cortex` | Unchanged from v0.1.0 |
| `templates/.cortex/brain.cortex` | Unchanged from v0.1.0 |
| `templates/.cortex/learn-policies.cortex` | Regenerated from `default_policy_text()` — now includes the 5 v0.2.0 config blocks |

### 2.5 Scripts

| File | Change |
|---|---|
| `scripts/install_local.sh` | Rewritten to handle both fresh installs and v0.1.0 → v0.2.0 upgrades; idempotent subcommand registration. |
| `scripts/run_regression.sh` | Extended with v0.2.0-specific smoke tests (session lifecycle, policy profile, feedback, pre/post-action). |

### 2.6 Documentation

| File | Purpose |
|---|---|
| `README_INSTALL.md` | Quick-start guide for end users |
| `PATCH_SUMMARY.md` | This file |
| `CERTIFICATION_REPORT.md` | Final certification report with evidence |
| `learning-engine-evolution.md` | The evolution design document (provided by the user) |
| `CODEC_CORTEX_LEARNING_ENGINE_SPEC.md` | The v0.1.0 specification (still applies) |

---

## 3. Files modified in target project

### 3.1 `cli/src/cortex/cli/main.py`

Added two subparser registrations just before `return p` in `build_parser()`:

```python
from ..learning.cli import add_learn_subparser
add_learn_subparser(sub)

from ..learning.session_cli import add_session_subparser
add_session_subparser(sub)
```

Also extended the `canonical_cmd` builder to include `learn_command`, `policy_command`, `index_command`, `session_command` dests.

### 3.2 `cli/src/cortex/core/modes.py`

Extended `READ_ONLY_COMMANDS`:

```python
"learn feedback-show", "learn pre-action", "learn post-action",
"session status",
```

Extended `WRITE_COMMANDS`:

```python
"learn policy set", "learn policy profile", "learn policy reset",
"learn feedback",
"session start", "session consolidate", "session close",
```

### 3.3 `cli/pyproject.toml`

Added `"cortex.learning"` to the `tool.setuptools.packages` list (same as v0.1.0 — no further change needed).

---

## 4. Commands added in v0.2.0

| Command | Fase | Mode |
|---|:---:|---|
| `cortex session start [--input "..."]` | A | write |
| `cortex session status` | A | read |
| `cortex session consolidate --input "..." --output "..." --outcome "..."` | A | write |
| `cortex session close [--no-consolidate] [--no-decay]` | A | write |
| `cortex learn pre-action --input "..."` | B | read |
| `cortex learn post-action [--modified]` | B | read |
| `cortex learn feedback --accept\|--reject --candidate <id> [--reason "..."] [--type ...] [--score N]` | D | write |
| `cortex learn feedback-show` | D | read |
| `cortex learn policy set <target> [--ses N] [--lng N] [--knw N] [--auto-knw N] [--half-life N] [--window "Nh"] [--occurrences N] [--adaptive true\|false] [--adjustment-rate F] [--patterns "..."]` | E | write |
| `cortex learn policy profile <default\|aggressive\|conservative>` | E | write |
| `cortex learn policy reset` | E | write |
| `cortex learn index rebuild --if-stale` | (extension) | write |

---

## 5. Technical decisions

### 5.1 Session state is stored IN the brain, not just in a sidecar cache

`SES:current` and `SES:last` are written into `brain.cortex` itself (per SPEC §A.2). The sidecar `.cortex/cache/session.json` mirrors the counters and events for fast access, but the brain is the source of truth. This keeps the engine stateless across runs and means that a fresh agent can pick up where the previous one left off just by reading the brain.

### 5.2 Decay never touches brain.cortex

Decay mutates **only** the learn-index (a derived cache). It reduces `hotness_score` and `promotion_score` on cooled entries, and drops entries whose cooled scores fall below `cooling.min_score_to_survive`. The brain retains all canonical entries forever — cooling only affects which entries the engine considers "hot" for the next session.

### 5.3 Structural sigils never decay

Even without an explicit `survive:"min"` attribute, the engine exempts `IDN`, `DOM`, `FCS`, `OBJ`, `STP`, `CNST`, `REF` from decay. These sigils define the workspace's identity and structure; cooling them would corrupt the workspace.

### 5.4 Feedback adjustment requires ≥3 records

The adaptive-threshold logic in `adjust_thresholds` only fires when a candidate-type has ≥3 feedback records. This prevents threshold thrash on the first one or two decisions. The thresholds are clamped to `[feedback.min_threshold, feedback.max_threshold]` (default `[1, 20]`).

### 5.5 Pre/post-action handlers never mutate the brain

`pre_action` writes only to `.cortex/cache/signals.json` (an accumulator). `post_action` reads the brain + index + accumulator and emits notifications, but never writes to the brain. The actual elevation is still gated behind an explicit `cortex learn elevate` command. This preserves the v0.1.0 contract: "the LLM cannot mutate brain or policies directly".

### 5.6 `last_accessed` is preserved across index rebuilds

`rebuild_index` accepts a `previous_index` parameter; when provided, it copies each entry's `last_accessed` timestamp from the previous index. This means rebuilding the index (e.g. after a brain mutation) does not reset decay history.

### 5.7 Profiles are text-substitution templates

The `aggressive` and `conservative` profiles are generated by string-substituting the relevant `POL:*{...}` lines in the default policy text. This keeps the profile definitions in one place (`policy_defaults.py`) and avoids duplicating the entire policy text. The downside: if a user has heavily customised their `learn-policies.cortex`, applying a profile will overwrite their customisations. This is documented in the `--confirm` gate.

---

## 6. Deviations from the evolution document

### 6.1 MCP server (Fase G) not implemented

Per the user's explicit request, Fase G (MCP server) is **excluded** from v0.2.0. The `tool catalog` JSON in §G.2 is preserved in the evolution document for future reference.

### 6.2 `feedback propose` LLM-interpretation not implemented

The evolution document §D shows `cortex learn feedback --reject <id> --reason "..."` storing the reason as an "anti-pattern LNG". The implementation records the reason in the `FeedbackRecord.reason` field but does NOT auto-create an anti-pattern LNG entry in the brain — that would require either an LLM (forbidden) or a deterministic transformation that the document does not specify. The reason is queryable via `cortex learn feedback-show` and can be manually promoted to an LNG by the user.

### 6.3 Decay runs at `session close`, not continuously

The evolution document §C shows decay running as part of `session_close`. The implementation honors this — decay is NOT applied on every `learn scan` or `learn index rebuild`. This preserves determinism: the index is a function of (brain, policy, engine_version), and decay is a separate, time-aware pass that only runs at session close.

### 6.4 Pre-action theme extraction is intentionally simple

The heuristic in `handlers._extract_themes` is a stopword-filtered tokenizer. It does NOT use stemming, lemmatisation, or any NLP library — those would require external dependencies and likely an LLM for proper disambiguation. The scoring layer (Fibonacci signals) does the heavy lifting; the theme extractor just provides a cheap recurrence signal.

### 6.5 `cortex learn feedback --type` is optional

When `--type` is omitted, the engine tries to infer the candidate type by looking up the candidate in the live candidates list. If the candidate id is not found, the engine falls back to treating the input as a raw selector (e.g. `SES:foo`) and infers the type from the sigil. This makes the CLI more ergonomic for interactive use.

---

## 7. What did NOT change

The following v0.1.0 areas are untouched in v0.2.0:

- `cli/src/cortex/core/` (parser, lexer, AST, writer, validator, errors) — unchanged.
- `cli/src/cortex/cli/commands/` (existing commands) — unchanged.
- `cli/src/cortex/hcortex/`, `cli/src/cortex/v2/`, `cli/src/cortex/crud/`, `cli/src/cortex/glossary/`, `cli/src/cortex/templates/`, `cli/src/cortex/audit/`, `cli/src/cortex/security/` — unchanged.
- `cortex/learning/conditions.py`, `cortex/learning/candidates.py`, `cortex/learning/elevation.py` — unchanged (v0.1.0 logic preserved).
- All 49 v0.1.0 tests — unchanged (still pass).

v0.2.0 is a **pure addition**; it does not alter any v0.1.0 behaviour.
