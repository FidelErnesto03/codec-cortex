# CODEC-CORTEX Learning Engine v0.2.0 — Installation Guide

**Version:** 0.2.0
**Algorithm:** `golden_fibonacci_v1`
**Engine evolution document:** `learning-engine-evolution.md`

This package extends the [CODEC-CORTEX](https://github.com/FidelErnesto03/codec-cortex) CLI with a deterministic, local-first learning engine. v0.2.0 adds session lifecycle, auto-detection handlers, exponential decay, adaptive feedback loop and configurable threshold profiles.

---

## 1. Prerequisites

- Python ≥ 3.10
- `pip` available on `$PATH`
- A local checkout of `codec-cortex` (tested against v0.3.6 / commit `9999399`)

---

## 2. What's new in v0.2.0

| Fase | Feature | Commands |
|:----:|---|---|
| **A** | Ciclo de sesión | `cortex session start/status/consolidate/close` |
| **B** | Auto-detección en handlers | `cortex learn pre-action/post-action` |
| **C** | Decay y enfriamiento | Automatic on `session close` (cooling_factor with half-life) |
| **D** | Feedback loop | `cortex learn feedback --accept/--reject`, `cortex learn feedback-show` |
| **E** | Thresholds configurables | `cortex learn policy set/profile/reset` |

**Not implemented** (out of scope per the user's request): Fase G — MCP server.

---

## 3. Install

```bash
# Extract the package
tar -xzf codec-cortex-learning-engine-0.2.0.tar.gz
cd codec-cortex-learning-engine-0.2.0

# Install into your codec-cortex checkout
./scripts/install_local.sh /ruta/al/proyecto/codec-cortex
```

The installer is **idempotent** and safe to re-run on a v0.1.0-installed tree. It will:

1. Copy the `cortex/learning/` package (15 modules).
2. Patch `main.py` to register `learn` + `session` subcommands.
3. Patch `modes.py` to classify all new commands in the read/write sets.
4. Patch `pyproject.toml` to include `cortex.learning` in the packages list.
5. Copy templates, schema and tests into the target tree.
6. Re-install the CLI in editable mode (`pip install -e ./cli`).

After installation, `cortex learn --help` and `cortex session --help` are available.

---

## 4. Verify

```bash
./scripts/run_regression.sh /ruta/al/proyecto/codec-cortex
```

Expected output:

```text
=== CODEC-CORTEX Learning Engine v0.2.0 — Regression Suite ===
[1/6] running existing pytest suite (no coverage gate)...
464 passed, 3 skipped
  PASS
[2/6] running v0.2.0 learning-engine tests...
47 passed
  PASS
[3/6] running python -m compileall on cli/src...
  PASS
[4/6] running pip check...
  PASS
[5/6] scanning learning engine for forbidden patterns...
  - LLM / network libraries ...  PASS (none found)
  - eval() / exec() calls ...    PASS (none found)
[6/6] CLI smoke test ...
  doctor: PASS
  index rebuild: PASS
  session start: PASS
  session status: PASS
  session close: PASS
  policy profile aggressive: PASS
  feedback accept: PASS
  pre-action: PASS
  post-action: PASS
=== ALL CHECKS PASSED ===
```

---

## 5. Quick start

```bash
# Initialise a workspace
cortex learn init --workspace .

# Apply a predefined profile (aggressive / conservative / default)
cortex learn policy profile aggressive --confirm

# Build the index
cortex learn index rebuild

# Start a session
cortex session start --input "morning kickoff"

# Detect recurrent themes before acting on user input
cortex learn pre-action --input "Revisemos los benchmarks otra vez"

# After the action, evaluate accumulated signals
cortex learn post-action

# List elevation candidates
cortex learn candidates --limit 10 --json

# Record feedback on a candidate (lowers/raises thresholds adaptively)
cortex learn feedback --accept --candidate cand_001
cortex learn feedback --reject --candidate cand_002 --reason "one-time event"

# Show feedback history and adjusted thresholds
cortex learn feedback-show

# Close the session (consolidates into SES:last + runs decay)
cortex session close --input "i" --output "o" --outcome "k"
```

---

## 6. Workspace layout

After `cortex learn init` + `cortex session start`, the workspace contains:

```text
.cortex/
  MANIFEST.cortex                  # canonical artefact map
  brain.cortex                     # operational memory (carries SES:current / SES:last)
  learn-policies.cortex            # external policy set (incl. v0.2.0 config blocks)
  index/
    learn-index.json               # rebuildable performance index (with last_accessed)
  cache/
    session.json                   # v0.2.0 session state cache
    signals.json                   # v0.2.0 pre/post-action signal accumulator
    feedback.json                  # v0.2.0 feedback history + adjusted thresholds
    fingerprints.json              # reserved
    candidates.json                # reserved
```

All cache files are **derived** — deleting them and running `cortex learn index rebuild` + `cortex session start` regenerates them.

---

## 7. What the engine will NEVER do

Per SPEC §1 (still enforced in v0.2.0):

- It will **not** call any LLM (OpenAI, Anthropic, …).
- It will **not** make any network request (`requests`, `httpx`, `urllib`).
- It will **not** use `eval()` or `exec()` to evaluate policy conditions.
- It will **not** mutate `brain.cortex` during `learn scan` / `learn candidates` / `learn explain`.
- It will **not** allow common policies to elevate protected sigils.
- It will **not** decay entries with `survive:"min"` or structural sigils (IDN, DOM, FCS, OBJ, STP, CNST, REF).

Every one of these guarantees is enforced by an automated test in `tests/test_learning_engine.py` and `tests/test_learning_engine_v02.py`.

---

## 8. Documentation

- `PATCH_SUMMARY.md` — Files created/modified, technical decisions, deviations.
- `CERTIFICATION_REPORT.md` — Full certification transcript with evidence.
- `CODEC_CORTEX_LEARNING_ENGINE_SPEC.md` — The v0.1.0 specification (still applies).
- `learning-engine-evolution.md` — The v0.2.0 evolution design document.

---

## 9. Uninstall

```bash
cd /ruta/al/proyecto/codec-cortex
rm -rf cli/src/cortex/learning
rm -f cli/src/tests/test_learning_engine.py cli/src/tests/test_learning_engine_v02.py
git checkout cli/src/cortex/cli/main.py cli/src/cortex/core/modes.py cli/pyproject.toml
pip install -e ./cli
```

---

## 10. License

MIT (same as codec-cortex).
