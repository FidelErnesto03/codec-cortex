# Certification Report — CODEC-CORTEX Learning Engine v0.2.0

**Certification date:** 2026-07-02
**Evolution document:** `learning-engine-evolution.md` (Fases A–E)
**Baseline spec:** `CODEC_CORTEX_LEARNING_ENGINE_SPEC.md` (v0.1.0)
**Engine version:** 0.2.0
**Algorithm:** `golden_fibonacci_v1`
**Package:** `codec-cortex-learning-engine-0.2.0.tar.gz`
**Package SHA-256:** see sidecar `codec-cortex-learning-engine-0.2.0.tar.gz.sha256` shipped alongside the tarball. (The hash is intentionally NOT embedded inside the tarball to avoid a chicken-and-egg hash recomputation loop.)
**Target commit:** `9999399` (codec-cortex v0.3.6)

---

## 1. Final declaration

```text
CERTIFICATION: PASS
Package: codec-cortex-learning-engine-0.2.0.tar.gz
Existing tests (v0.1.0 + base): PASS (464 passed, 3 skipped)
New v0.2.0 tests:               PASS (47 passed)
Regression:                     PASS
No LLM calls:                   PASS
No network calls:               PASS
No eval/exec:                   PASS
Index rebuildable:              PASS
Critical sigils protected:      PASS
Session lifecycle:              PASS
Decay + cooling:                PASS
Feedback loop:                  PASS
Configurable thresholds:        PASS
Pre/post-action handlers:       PASS
```

---

## 2. Package contents

28 files, organised as follows:

```text
codec-cortex-learning-engine-0.2.0/
  README_INSTALL.md
  CERTIFICATION_REPORT.md             (this file)
  PATCH_SUMMARY.md
  CODEC_CORTEX_LEARNING_ENGINE_SPEC.md   (v0.1.0 spec, still applies)
  learning-engine-evolution.md         (v0.2.0 evolution document)
  cli/
    pyproject.toml                    (patched: adds cortex.learning package)
    src/cortex/
      cli/main.py                     (patched: registers learn + session subcommands)
      core/modes.py                   (patched: classifies learn + session commands)
      learning/
        __init__.py                   (v0.2.0)
        errors.py                     (v0.2.0: 4 new error codes)
        conditions.py                 (v0.1.0, unchanged)
        workspace.py                  (v0.1.0, unchanged)
        policy_defaults.py            (v0.2.0: profiles)
        policy.py                     (v0.2.0: 5 new config dataclasses)
        scoring.py                    (v0.2.0: last_accessed field)
        index.py                      (v0.2.0: preserve last_accessed)
        candidates.py                 (v0.1.0, unchanged)
        elevation.py                  (v0.1.0, unchanged)
        cli.py                        (v0.2.0: 7 new command handlers)
        session.py                    (v0.2.0 NEW)
        session_cli.py                (v0.2.0 NEW)
        handlers.py                   (v0.2.0 NEW)
        decay.py                      (v0.2.0 NEW)
        feedback.py                   (v0.2.0 NEW)
  tests/
    test_learning_engine.py           (v0.1.0 tests — 49)
    test_learning_engine_v02.py       (v0.2.0 tests — 47)
  templates/.cortex/
    MANIFEST.cortex
    brain.cortex
    learn-policies.cortex             (v0.2.0: includes config blocks)
  schemas/
    learn-index.schema.json
  scripts/
    install_local.sh                  (executable, v0.2.0-aware)
    run_regression.sh                 (executable, v0.2.0 smoke tests)
```

---

## 3. Files installed / modified in target project

### 3.1 Created

```text
cli/src/cortex/learning/__init__.py        (updated to v0.2.0)
cli/src/cortex/learning/errors.py          (updated to v0.2.0)
cli/src/cortex/learning/conditions.py
cli/src/cortex/learning/workspace.py
cli/src/cortex/learning/policy_defaults.py (updated to v0.2.0)
cli/src/cortex/learning/policy.py          (updated to v0.2.0)
cli/src/cortex/learning/scoring.py         (updated to v0.2.0)
cli/src/cortex/learning/index.py           (updated to v0.2.0)
cli/src/cortex/learning/candidates.py
cli/src/cortex/learning/elevation.py
cli/src/cortex/learning/cli.py             (updated to v0.2.0)
cli/src/cortex/learning/session.py         (v0.2.0 NEW)
cli/src/cortex/learning/session_cli.py     (v0.2.0 NEW)
cli/src/cortex/learning/handlers.py        (v0.2.0 NEW)
cli/src/cortex/learning/decay.py           (v0.2.0 NEW)
cli/src/cortex/learning/feedback.py        (v0.2.0 NEW)
cli/src/tests/test_learning_engine.py      (v0.1.0 tests)
cli/src/tests/test_learning_engine_v02.py  (v0.2.0 tests, NEW)
templates/.cortex/MANIFEST.cortex
templates/.cortex/brain.cortex
templates/.cortex/learn-policies.cortex    (v0.2.0 config blocks)
schemas/learn-index.schema.json
```

### 3.2 Modified

```text
cli/src/cortex/cli/main.py     +12 lines  (register learn + session subcommands)
cli/src/cortex/core/modes.py   +12 lines  (classify learn + session commands)
cli/pyproject.toml             +1 line    (add cortex.learning to packages)
```

---

## 4. Test results

### 4.1 Existing test suite (v0.1.0 + base)

Command: `python -m pytest cli/src/tests --no-cov -q --ignore=cli/src/tests/test_learning_engine_v02.py`

```text
........................................................................ [ 15%]
........................................................................ [ 30%]
........................................................................ [ 46%]
.............s......................................s................... [ 61%]
........................................................................ [ 77%]
.............................................s.......................... [ 92%]
...................................                                      [100%]
464 passed, 3 skipped in 29.88s
  PASS
```

### 4.2 v0.2.0 tests

Command: `python -m pytest cli/src/tests/test_learning_engine_v02.py --no-cov -q`

```text
...............................................                          [100%]
47 passed in 4.75s
  PASS
```

Test breakdown by category:

| Class | Tests | Coverage |
|---|---:|---|
| `TestConfigurableThresholds` | 6 | Fase E — fibonacci_thresholds / cooling / detection / feedback / protected_patterns parsing + profiles |
| `TestSessionLifecycle` | 8 | Fase A — start / status / consolidate / close; SES:current / SES:last lifecycle |
| `TestHandlers` | 5 | Fase B — pre_action theme detection + accumulation; post_action candidate notifications |
| `TestDecay` | 8 | Fase C — cooling_factor math; drop old entries; preserve structural sigils; partial cooling; survive:"min" exemption |
| `TestFeedback` | 7 | Fase D — record_feedback persistence; adjust_thresholds (raise/lower/skip); min-3-records rule; adaptive=false skip |
| `TestFullSessionLifecycle` | 1 | End-to-end: start → pre → post → feedback → close |
| `TestV02CLI` | 7 | CLI subprocess tests for session, policy profile/set/reset, feedback, pre/post-action |
| `TestV02ForbiddenPatterns` | 3 | No LLM/network imports; no eval/exec; engine version is 0.2.0 |
| `TestBackwardsCompat` | 2 | SPEC §17 cand_001 score=13 still holds; last_accessed preserved across rebuild |
| **Total** | **47** | |

### 4.3 compileall

Command: `python -m compileall -q cli/src`

```text
  PASS
```

### 4.4 pip check

Command: `python -m pip check`

```text
No broken requirements found.
  PASS
```

---

## 5. Forbidden-pattern scans

### 5.1 LLM / network libraries

Command: `rg -n "openai|anthropic|requests|httpx|urllib" cli/src/cortex/learning`

```text
(no matches)
  PASS
```

### 5.2 `eval()` / `exec()` calls

Command: `rg -n "eval\(|exec\(" cli/src/cortex/learning`

```text
(no matches)
  PASS
```

The scan covers all 15 modules in `cortex/learning/` (v0.1.0 + v0.2.0).

---

## 6. v0.2.0 feature certification

### 6.1 Fase A — Ciclo de sesión

| Criterion | Status | Evidence |
|---|---|---|
| `cortex session start` creates `SES:current` in brain | **PASS** | `TestSessionLifecycle::test_start_creates_ses_current` |
| Starting twice raises `LE014_SESSION_ALREADY_RUNNING` | **PASS** | `TestSessionLifecycle::test_start_twice_blocks` |
| `cortex session status` reports active session | **PASS** | `TestSessionLifecycle::test_status_active_session` |
| `cortex session consolidate` writes `SES:last` | **PASS** | `TestSessionLifecycle::test_consolidate_writes_ses_last` |
| `cortex session close` removes `SES:current`, keeps `SES:last` | **PASS** | `TestSessionLifecycle::test_close_removes_ses_current` |
| Close without active session raises `LE015` | **PASS** | `TestSessionLifecycle::test_close_without_session_errors` |
| Close with `run_decay=True` runs decay | **PASS** | `TestSessionLifecycle::test_close_with_decay_runs_decay` |

### 6.2 Fase B — Auto-detección en handlers

| Criterion | Status | Evidence |
|---|---|---|
| `pre_action` detects themes in user input | **PASS** | `TestHandlers::test_pre_action_detects_themes` |
| Themes accumulate across calls | **PASS** | `TestHandlers::test_pre_action_accumulates_signals` |
| `post_action` emits candidate notifications | **PASS** | `TestHandlers::test_post_action_emits_notifications` |
| `post_action --modified` logs a session event | **PASS** | `TestHandlers::test_post_action_with_modification_logs_session_event` |
| Handlers never mutate `brain.cortex` | **PASS** | Code inspection: `handlers.py` only writes to `cache/signals.json` |

### 6.3 Fase C — Decay y enfriamiento

| Criterion | Status | Evidence |
|---|---|---|
| `cooling_factor(0) == 1.0` | **PASS** | `TestDecay::test_cooling_factor_zero_days` |
| `cooling_factor(7) ≈ 0.5` (half-life) | **PASS** | `TestDecay::test_cooling_factor_half_life` |
| `cooling_factor(14) ≈ 0.25` (two half-lives) | **PASS** | `TestDecay::test_cooling_factor_two_half_lives` |
| `cooling_factor(30) ≈ 0.05` | **PASS** | `TestDecay::test_cooling_factor_30_days` |
| 30-day-old entries are dropped | **PASS** | `TestDecay::test_apply_decay_drops_old_entries` |
| Structural sigils (IDN/DOM/CNST) preserved | **PASS** | `TestDecay::test_apply_decay_preserves_structural_sigils` |
| 14-day-old entries are cooled, not dropped | **PASS** | `TestDecay::test_apply_decay_cools_but_keeps_partial` |
| `survive:"min"` entries never decay | **PASS** | `TestDecay::test_survive_min_never_decays` |

### 6.4 Fase D — Feedback loop

| Criterion | Status | Evidence |
|---|---|---|
| `record_feedback` persists to `cache/feedback.json` | **PASS** | `TestFeedback::test_record_feedback_persists` |
| High acceptance rate lowers threshold | **PASS** | `TestFeedback::test_adjust_thresholds_lowers_when_acceptance_high` |
| Low acceptance rate raises threshold | **PASS** | `TestFeedback::test_adjust_thresholds_raises_when_acceptance_low` |
| `adaptive=false` disables adjustment | **PASS** | `TestFeedback::test_adjust_thresholds_skipped_when_adaptive_false` |
| <3 records → no adjustment | **PASS** | `TestFeedback::test_adjust_thresholds_needs_min_three_records` |
| `derive_sigil_pattern` strips numeric suffixes | **PASS** | `TestFeedback::test_derive_sigil_pattern_strips_numeric_suffix` |

### 6.5 Fase E — Thresholds configurables

| Criterion | Status | Evidence |
|---|---|---|
| Default policy has all 5 config blocks | **PASS** | `TestConfigurableThresholds::test_default_policy_has_v02_blocks` |
| Config blocks parse into typed dataclasses | **PASS** | `TestConfigurableThresholds::test_default_parses_to_config_objects` |
| Aggressive profile changes thresholds | **PASS** | `TestConfigurableThresholds::test_aggressive_profile_changes_thresholds` |
| Conservative profile changes thresholds | **PASS** | `TestConfigurableThresholds::test_conservative_profile_changes_thresholds` |
| `PROFILES` dict has 3 entries | **PASS** | `TestConfigurableThresholds::test_profiles_dict_has_three_entries` |
| `protected_patterns` matches globs | **PASS** | `TestConfigurableThresholds::test_protected_patterns_match` |

---

## 7. CLI smoke test transcript

The `run_regression.sh` script ran the following v0.2.0 CLI commands end-to-end on a temporary workspace:

```text
[6/6] CLI smoke test on a temporary workspace...
  doctor: PASS
  index rebuild: PASS
  session start: PASS
  session status: PASS
  session close: PASS
  policy profile aggressive: PASS
  feedback accept: PASS
  pre-action: PASS
  post-action: PASS
```

Each step verifies a specific v0.2.0 feature:

1. `doctor` — workspace integrity (v0.1.0 baseline)
2. `index rebuild` — index rebuild (v0.1.0 baseline, now preserves `last_accessed`)
3. `session start` — Fase A: creates `SES:current`
4. `session status` — Fase A: reports active session
5. `session close` — Fase A: consolidates + closes (decay disabled in smoke)
6. `policy profile aggressive` — Fase E: applies aggressive profile
7. `feedback accept` — Fase D: records accept decision
8. `pre-action` — Fase B: detects themes in user input
9. `post-action` — Fase B: emits candidate notifications

---

## 8. Backwards compatibility with v0.1.0

| Criterion | Status | Evidence |
|---|---|---|
| All 49 v0.1.0 tests pass | **PASS** | §4.1 (464 passed includes the 49 v0.1.0 tests) |
| SPEC §16 brain still produces `cand_001` with `promotion_score=13` | **PASS** | `TestBackwardsCompat::test_v01_spec_brain_still_produces_cand_001_score_13` |
| `last_accessed` preserved across index rebuild | **PASS** | `TestBackwardsCompat::test_index_preserves_last_accessed_across_rebuild` |
| Engine version bumped to `0.2.0` | **PASS** | `TestV02ForbiddenPatterns::test_engine_version_is_v02` |
| Existing CLI commands unchanged | **PASS** | Manual inspection: `cortex learn init/doctor/scan/candidates/elevate` all work identically |

---

## 9. v0.1.0 certification criteria (still hold)

All 15 mandatory criteria from `CODEC_CORTEX_LEARNING_ENGINE_SPEC.md` §12 still pass:

| Criterion | Status |
|---|---|
| Existing tests pass | **PASS** |
| New learning tests pass | **PASS** |
| `learn init` idempotent | **PASS** |
| `learn doctor` detects inconsistencies | **PASS** |
| `learn index rebuild` deterministic | **PASS** |
| Index invalidated by hash | **PASS** |
| `learn scan` does not mutate brain | **PASS** |
| `learn candidates` orders by priority | **PASS** |
| `learn elevate --dry-run` does not mutate | **PASS** |
| `learn elevate --apply` respects policy | **PASS** |
| Critical sigils protected | **PASS** |
| No use of LLM | **PASS** |
| No use of network | **PASS** |
| No use of `eval`/`exec` | **PASS** |
| Compressed package generated | **PASS** |

---

## 10. End-to-end regression transcript

The script `scripts/run_regression.sh` was executed against a fresh clone of `codec-cortex` (commit `9999399`) immediately after `scripts/install_local.sh`. Full transcript:

```text
=== CODEC-CORTEX Learning Engine v0.2.0 — Regression Suite ===
Target: /home/z/my-project/workspace/codec-cortex-v2-test

[1/6] running existing pytest suite (no coverage gate)...
........................................................................ [ 15%]
........................................................................ [ 30%]
........................................................................ [ 46%]
.............s......................................s................... [ 61%]
........................................................................ [ 77%]
.............................................s.......................... [ 92%]
...................................                                      [100%]
464 passed, 3 skipped in 29.88s
  PASS

[2/6] running v0.2.0 learning-engine tests...
...............................................                          [100%]
47 passed in 4.75s
  PASS

[3/6] running python -m compileall on cli/src...
  PASS

[4/6] running pip check...
No broken requirements found.
  PASS

[5/6] scanning learning engine for forbidden patterns...
  - LLM / network libraries (openai|anthropic|requests|httpx|urllib)...
    PASS (none found)
  - eval() / exec() calls...
    PASS (none found)

[6/6] CLI smoke test on a temporary workspace...
  doctor: PASS
  index rebuild: PASS
  session start: PASS
  session status: PASS
  session close: PASS
  policy profile aggressive: PASS
  feedback accept: PASS
  pre-action: PASS
  post-action: PASS

=== ALL CHECKS PASSED ===
```

---

## 11. Reproduction

Anyone can reproduce this certification by running:

```bash
# 1. Extract the package
tar -xzf codec-cortex-learning-engine-0.2.0.tar.gz
cd codec-cortex-learning-engine-0.2.0

# 2. Clone a fresh copy of codec-cortex
git clone https://github.com/FidelErnesto03/codec-cortex.git /tmp/cc

# 3. Install the learning engine into it
./scripts/install_local.sh /tmp/cc

# 4. Run the full regression suite
./scripts/run_regression.sh /tmp/cc
```

The expected output is the transcript in §10. The certification is **PASS** if and only if every check prints `PASS` and the script exits with code 0.

---

## 12. Final declaration

The CODEC-CORTEX Learning Engine v0.2.0 is **CERTIFIED** for installation into the codec-cortex project. All five evolution fases (A–E) are implemented, all 47 new tests pass, all 49 v0.1.0 tests still pass, and all v0.1.0 certification criteria continue to hold.

```text
CERTIFICATION: PASS
```
