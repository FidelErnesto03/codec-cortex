<!-- SPDX-FileCopyrightText: 2026 Fidel Ernesto Lozada A. -->
<!-- SPDX-License-Identifier: MIT -->

# INFORME DE ENTREGA — v0.3.4 (Phase E2 — Security & Governance)

> Endurecimiento del CLI y el protocolo contra mal uso, fuga de secretos
> y mutaciones no autorizadas.

**Fecha:** 2026-07-01  
**Versión origen:** v0.3.3 (tag en git)  
**Versión destino:** v0.3.4  
**Plan de referencia:** `e2-security-governance.md`  
**Tests:** 409 passed (341 originales + 68 nuevos E2), 3 skipped, 0 failed.

---

## 1. Entregables por sub-item

| ID | Entregable | Estado | Archivos |
|:--:|------------|:------:|:--------:|
| E2.1 | Dependabot config | ✅ | `.github/dependabot.yml` |
| E2.2 | Secret scanner (pre-commit + doctor) | ✅ | `cortex/security/secret_scanner.py`, `doctor.py`, `.pre-commit-config.yaml`, `.secrets.baseline` |
| E2.3 | Mutation gates (read-only/editor/admin) | ✅ | `cortex/core/modes.py`, `main.py`, `errors.py` |
| E2.4 | Audit log (on-demand) | ✅ | `cortex/audit/logger.py`, `cortex/cli/commands/audit.py`, `main.py` |
| E2.5 | Release signing (SHA256SUMS) | ✅ | `scripts/sign_release.py` |
| E2.6 | `cortex verify --signature` | ✅ | `cortex/security/signature.py`, `verify.py`, `main.py` |

---

## 2. Criterios de aceptación (Plan E2 §9)

- [x] Pre-commit hooks bloquean secretos (`ghp_`, `pypi-`, etc.)
- [x] `cortex doctor` incluye scan de secretos
- [x] `cortex --mode read-only` bloquea todas las escrituras (rc=13, E035)
- [x] `cortex --mode editor --force` pide confirmación (interactivo); CI procede
- [x] Cada mutación CRUD solo se loguea si `cortex audit on` está activo
- [x] `cortex audit status` muestra estado del logging
- [x] `cortex audit snapshot` exporta punto único a `~/.codec-cortex/audit/`
- [x] SHA256SUMS se genera con `scripts/sign_release.py`
- [x] `cortex verify --signature` verifica integridad
- [x] Dependabot configurado (`.github/dependabot.yml`)
- [x] 409 tests pasan (sin regresión; +68 nuevos)
- [x] Ruff 0 errores (código Python pasa lint)

---

## 3. Evidence

```bash
cortex --version                                            # 0.3.4.dev0
cortex audit status                                         # enabled: false
cortex audit on                                             # enabled: true
cortex --mode read-only delete brain.cortex FCS:primary     # E035_MODE_READ_ONLY, rc=13
cortex doctor skill/cortex/SKILL.md --scan-secrets          # exit 0
cortex verify skill/cortex/SKILL.md --signature SHA256SUMS  # ok=True, rc=0
python scripts/sign_release.py --dist-dir cli/dist/         # generates SHA256SUMS
python -m pytest src/tests/ -q                              # 409 passed, 3 skipped
```

---

## 4. Nuevos módulos

### `cortex/security/` (E2.2 + E2.6)
- `secret_scanner.py` — 12 patrones (8 high, 4 medium), scan_text/file/paths, baseline, redact.
- `signature.py` — SHA256SUMS manifest parse + verify, SignatureResult dataclass.

### `cortex/core/modes.py` (E2.3)
- `Mode` enum (READ_ONLY, EDITOR, ADMIN).
- `resolve_mode()` — prioridad: --mode > $CORTEX_MODE > editor.
- `check_permission()` — clasifica comandos y aplica reglas por modo.
- `annotate_args()` — propaga modo a los command handlers.

### `cortex/audit/` (E2.4)
- `logger.py` — session state, append-only JSONL, snapshot, prune, rotate.
- Solo escribe cuando `cortex audit on` está activo.

### `cortex/cli/commands/audit.py` (E2.4)
- Subcomandos: `on`, `off`, `status`, `snapshot`, `prune`.

### `scripts/sign_release.py` (E2.5)
- Genera/verifica `SHA256SUMS` para `*.whl` y `*.tar.gz`.

---

## 5. Nuevos flags CLI

| Flag | Comando | Descripción |
|------|---------|-------------|
| `--mode {read-only,editor,admin}` | global | E2.3: mutation gate mode |
| `--yes` | global | E2.3: pre-confirmar destructivas |
| `--signature <manifest>` | `verify` | E2.6: verificar SHA256 |
| `--manifest <manifest>` | `verify` | E2.6: alias de --signature |
| `--scan-secrets` | `doctor` | E2.2: exit 2 si high finding |
| `--scan-secrets-paths <p>...` | `doctor` | E2.2: paths adicionales |
| `--secrets-baseline <f>` | `doctor` | E2.2: silenciar falsos positivos |

---

## 6. Nuevos error codes

| Code | Significado |
|------|-------------|
| E035_MODE_READ_ONLY | Escritura bloqueada en modo read-only |
| E036_MODE_EDITOR_CONFIRM | --force requiere confirmación en editor mode |
| E037_MODE_UNKNOWN | Modo no reconocido |
| E038_AUDIT_LOGGING_OFF | Auditoría desactivada |
| E039_SIGNATURE_MISMATCH | Hash SHA256 no coincide |
| E040_SECRET_DETECTED | Secreto detectado en scan |

---

## 7. Nuevos exit codes

| Code | Significado |
|------|-------------|
| 13 | Violación de mutation gate (E035/E036) |
| 2 | Secret high-severity detectado con `--scan-secrets` |

---

## 8. Env vars

| Var | Default | Descripción |
|-----|---------|-------------|
| `CORTEX_MODE` | (none → editor) | E2.3: modo de operación |
| `CORTEX_AUDIT_DIR` | `~/.codec-cortex/audit/` | E2.4: directorio de logs (override para tests) |

---

## 9. Tests por archivo

| Archivo | Tests | Cobertura |
|---------|:-----:|-----------|
| `test_e2_signature.py` | 12 | sha256_file, parse_manifest, verify_signature, CLI |
| `test_e2_secret_scanner.py` | 17 | patterns, severity, file scan, dir walk, baseline, redact |
| `test_e2_modes.py` | 16 | Mode enum, classification, resolve_mode, check_permission, CLI |
| `test_e2_audit.py` | 23 | session state, append_entry, AuditEntry, snapshot, CLI |
| **Total E2** | **68** | |

---

## 10. Pendientes

- Tag `v0.3.4` en git (después de aplicar el patch).
- Activar `detect-secrets` hook en CI (instalar `detect-secrets` en el runner).
- Verificar que Dependabot abre el primer PR (puede tardar hasta 1 semana).
- Considerar E2.7 (futuro): `cortex audit prune` automático en CI.
